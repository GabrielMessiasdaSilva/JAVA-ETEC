/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.etec.padrão;

import javax.swing.JOptionPane;

/**
 *
 * @author dti
 */
public class Principal {
    public static String texto;
    
    /**
     * 
     *   Declaração de atributos 
     */
    
    //Variavel do tipo caracter que armazena o tescto digitadao pelo usuario.
    
   public static void main (String[] args)
   {        
   
       //Receber texto pelo teclado,via janela grafica.
       texto=JOptionPane.showInputDialog("Digite o seu nome:");
   // Exibir texto via janela grafic.
   JOptionPane.showMessageDialog(null,"Aooba,seu primeiro programa..."+ "\n"+texto);
   }
}
   
   
   
   }
    
    
    
    
    
}
