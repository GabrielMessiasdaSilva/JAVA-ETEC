/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.etec.padrão;

/**
 *
 * @author dti
 */
public class Principal {
       /**
     * 
     *  Declaração de atributos
     */

/** Metodo:Main (principal)
 * 
 */
 public static void main (String[] args)
 {
     
     //Carrega na memoria o objeto da classe Util.
     Util util = new Util();
     
     //Executa o metodo solicitado.
     util.digitarTexto();
     
     //Executa o método solicitado.
     util.exibirTexto();
 }        
}








