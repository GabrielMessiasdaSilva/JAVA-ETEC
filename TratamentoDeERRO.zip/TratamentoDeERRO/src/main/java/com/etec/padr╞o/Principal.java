/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.etec.padrão;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author dti
 */
public class Principal {
public static Scanner teclado = new Scanner(System.in);
   
    public static String nome;
    
    public static int idade;
    
     public static float altura;
     
     public static boolean sn;
    
    public static void main(String args[])
    {
    
        System.out.println("Seja bem vindo a aplicação de cadastro...");
        
        try {
            System.out.println("Digite seu nome: ");
            nome = teclado.nextLine();
           
        }
        catch (InputMismatchException e1) {
            System.out.println("Olá, um erro aconteceu ao armazenar seu nome (Variavel Nula): " + e1.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
            
        }
        catch (NullPointerException e2){
            System.out.println("Olá, um erro aconteceu ao armazenar seu nome (Variavel Nula): " + e2.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);   
        }
       try
       {
        System.out.println("Digite sua idade: ");
       
       idade = teclado.nextInt();
       if (idade<=0)
       {
           System.out.println("A idade digita não é valida");
       }
       else{
       }
       }
       catch (InputMismatchException e3){
            System.out.println("Olá, um erro aconteceu ao armazenar sua idade (Variavel Nula): " + e3.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
       }
       catch(NullPointerException e4){
           System.out.println("Olá, um erro aconteceu ao armazenar sua idade (Variavel Nula): " + e4.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
       }
       try{
       System.out.println("Digite sua altura: ");
       
       
       altura = teclado.nextFloat();
       if(altura<=0){
           System.out.println("A altura inserida é invalida");
            System.exit(0);
       }
       else{
           
       }
       }
       catch(InputMismatchException e5){
            System.out.println("Olá, um erro aconteceu ao armazenar sua altura  (Variavel Nula): " + e5.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
       }
       catch(NullPointerException e6){
            System.out.println("Olá, um erro aconteceu ao armazenar sua altura (Variavel Nula): " + e6.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
       }
       try{
       System.out.println("Voce é Paulistano?Ou Paulista?Digite true para Paulistano ou false para Paulista: ");
       
       sn = teclado.nextBoolean();
       }
       catch(InputMismatchException e7){
            System.out.println("Olá, um erro aconteceu ao armazenar seu local de nascimento (Variavel Nula): " + e7.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
       }
       catch(NullPointerException e8){
            System.out.println("Olá, um erro aconteceu ao armazenar  seu local de nascimento (Variavel Nula): " + e8.getMessage());
            System.out.println("Execute o programa novamente, por favor []");
            System.exit(0);
       }
       
       System.out.println("Seu nome é: " + nome);
       
       System.out.println("Sua idade é: " + idade);
       
       System.out.println("Sua altura  é: " + altura);
       
       System.out.println("Você é Paulistano? : " + sn);
    }
    
}