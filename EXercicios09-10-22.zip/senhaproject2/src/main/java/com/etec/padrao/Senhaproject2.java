/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.etec.padrao;

import java.util.Scanner;

/**
 *
 * @author g
 */
public class Senhaproject2 {
public static Scanner teclado = new Scanner (System.in);
    public static void main(String[] args) {
     String sen;
        System.out.println("Digite a sua senha");
        sen=teclado.nextLine();
        if(sen.equals("carpem diem")){
            System.out.println("senha valida");
                    }else{
            System.out.println("senha invalida");
        }
    }
}
