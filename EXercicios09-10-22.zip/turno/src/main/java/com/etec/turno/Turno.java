/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.etec.turno;

import java.util.Scanner;

/**
 *
 * @author g
 */
public class Turno {

public static Scanner teclado = new Scanner (System.in);
    public static void main(String[] args) {
    
        double nota1;
        double  nota2;
        double  nota;
        double  nota3;
        double  nota4;
        double   media;
        
        System.out.println("por favor,informe as notas bimestral dos alunos");
        nota1 = teclado.nextDouble();
        nota2 = teclado.nextDouble();
        nota3 = teclado.nextDouble();
        nota4 = teclado.nextDouble();
        media = (nota1 + nota2 + nota3 + nota4) / 4;
        if (media >= 9) {
            System.out.println("A - Aprovado");
        } else {
            if (media >= 7) {
                System.out.println("b aluno aprovado");
            } else {
                if (media >= 5) {
                    System.out.println("c-Aprovado");
                } else {
                    if (media > 2.5) {
                        System.out.println("D-reprovado");
                    } else {
                        System.out.println("E-reprovado");
                    }
                }
            }
        }
    }
}
